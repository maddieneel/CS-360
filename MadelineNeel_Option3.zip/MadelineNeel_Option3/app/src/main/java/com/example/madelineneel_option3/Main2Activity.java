package com.example.madelineneel_option3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
    private EditText date;
    private EditText currentWeight;
    private EditText goalWeight;
    private Button submitInput;
    WeightDatabase DB;
    private ProgressBar progress;
    private ListView listView;
    private Switch notificationOnOff;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        date = (EditText) findViewById(R.id.inputDate);
        currentWeight = (EditText) findViewById(R.id.inputCurrentWeight);
        goalWeight = (EditText) findViewById(R.id.inputGoalWeight);
        submitInput = (Button) findViewById(R.id.submitInputButton);
        DB = new WeightDatabase(this);
        progress = (ProgressBar) findViewById(R.id.progressBar);
        listView = (ListView) findViewById(R.id.listView);
        notificationOnOff = (Switch) findViewById(R.id.notificationOnOff);

        //notification channel
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel channel = new NotificationChannel("My Notification", "My Notification", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }

        submitInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String date1 = date.getText().toString();
                final String currentWeight1 = currentWeight.getText().toString();
                final String goalWeight1 = goalWeight.getText().toString();

                if(date1.isEmpty() || currentWeight1.isEmpty() || goalWeight1.isEmpty()){
                    Toast.makeText(Main2Activity.this, "Please input date/weights.", Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean ifInDatabase = DB.checkDate(date1);
                    if(ifInDatabase == false){
                        Boolean insertWeightInfo = DB.insertWeight(date1, currentWeight1, goalWeight1);
                        if(insertWeightInfo == true){
                            Toast.makeText(Main2Activity.this, "Input Successful!", Toast.LENGTH_SHORT).show();
                            int goal = Integer.parseInt(goalWeight1);
                            int weight = Integer.parseInt(currentWeight1);
                            progress.setProgress(0);
                            progress.setMax(goal);
                            progress.incrementProgressBy(weight);
                            progress.setVisibility(View.VISIBLE);

                            if(notificationOnOff.isChecked() && (currentWeight1 == goalWeight1)){
                                showNotifications();
                            }

//                            notificationOnOff.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//                                @Override
//                                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
//                                    if (isChecked && (currentWeight1 == goalWeight1)){
//                                        showNotifications();
//                                    }
//                                    else{
//                                        Toast.makeText(Main2Activity.this, "You won't recieve a notification.", Toast.LENGTH_SHORT).show();
//                                    }
//                                }
//                            });


                        }
                        else{
                            Toast.makeText(Main2Activity.this, "Something went wrong, try again!", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(Main2Activity.this, "Weight already submitted today.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    public void showNotifications(){
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "My Notification");
        builder.setSmallIcon(R.drawable.ic_launcher_background);
        builder.setContentTitle("Weight Tracker");
        builder.setContentText("Congrats, you've reached your goal weight!");

        NotificationManagerCompat notificationManagerCompat = NotificationManagerCompat.from(Main2Activity.this);
        notificationManagerCompat.notify(0, builder.build());

//        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
//        notificationManager.notify(0, builder.build());
    }
}
