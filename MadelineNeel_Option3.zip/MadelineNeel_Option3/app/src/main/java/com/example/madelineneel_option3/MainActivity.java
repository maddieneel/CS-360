package com.example.madelineneel_option3;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText username;
    private EditText password;
    private Button login;
    private Button createAccount;
    LoginDatabase DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        login = (Button) findViewById(R.id.login);
        createAccount = (Button) findViewById(R.id.createAccount);
        DB = new LoginDatabase(this);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString();
                String pass = password.getText().toString();

                if(user.isEmpty() || pass.isEmpty()){
                    Toast.makeText(MainActivity.this, "Error, Username/Password Empty", Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean ifInDatabase = DB.checkusernamepassword(user, pass);
                    if(ifInDatabase == true){
                        Intent intent = new Intent(getApplicationContext(), Main2Activity.class);
                        startActivity(intent);
                    }
                    else{
                        Toast.makeText(MainActivity.this, "Account Not Found, Try Again or Register For New Account", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString();
                String pass = password.getText().toString();

                if(user.isEmpty() || pass.isEmpty()){
                    Toast.makeText(MainActivity.this, "Error, Username/Password Empty", Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean ifInDatabase = DB.checkUserName(user);
                    if(ifInDatabase == false){
                        Boolean insertUserInfo = DB.insertData(user, pass);
                        if (insertUserInfo == true){
                            Toast.makeText(MainActivity.this, "Account Created!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), Main2Activity.class);
                            startActivity(intent);
                        }
                        else{
                            Toast.makeText(MainActivity.this, "Something went wrong, try again!", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(MainActivity.this, "Account already exists.", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });
    }
}
