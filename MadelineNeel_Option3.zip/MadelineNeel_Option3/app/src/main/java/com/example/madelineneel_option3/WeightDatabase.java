package com.example.madelineneel_option3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.Date;

public class WeightDatabase extends SQLiteOpenHelper {
    public static final String DBNAME = "Weight.db";

    public WeightDatabase(Context context) {super (context, "Weight.db", null, 1);}

    @Override
    public void onCreate(SQLiteDatabase MyDB){
        MyDB.execSQL("create Table weight(date TEXT primary key, currentWeight TEXT, goalWeight TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1){
        MyDB.execSQL("drop Table if exists weight");
    }

    public Boolean insertWeight(String date, String currentWeight, String goalWeight){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("date", date);
        contentValues.put("currentWeight", currentWeight);
        contentValues.put("goalWeight", goalWeight);
        long result = MyDB.insert("weight", null, contentValues);
        if(result == -1){
            return false;
        }
        else{
            return true;
        }
    }

    public Boolean checkDate(String date){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from weight where date = ?", new String[] {date});
        if(cursor.getCount() > 0){
            return true;
        }
        else{
            return false;
        }
    }

    public long deleteInput(String date){
        return this.getWritableDatabase().delete("weight", "date = ?", new String[] {String.valueOf(date)});
    }

    public long updateInput(String date, String currentWeight, String goalWeight) {
        long updatedData = 0;
        ContentValues contentValues = new ContentValues();
        if(currentWeight != null) contentValues.put("currentWeight", currentWeight);
        if(goalWeight != null) contentValues.put("goalWeight", goalWeight);
        updatedData = this.getWritableDatabase().update("weight", contentValues, "date = ?", new String[]{String.valueOf(date)});
        return updatedData;
    }

    public Cursor getAll(){
        return this.getWritableDatabase().query("weight", null, null, null, null, null, null);
    }
}
